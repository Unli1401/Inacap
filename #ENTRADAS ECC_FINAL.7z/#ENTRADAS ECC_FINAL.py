#ENTRADAS ECC

# Definir los precios de las entradas
normal = int(8000)
vip = int(15000)
estreno = int(20000)
descuento_est = 0.2

# Definir la lista de asientos disponibles
asientos = list(range(1, 41))

# Inicializar el contador de asientos ocupados y el total a pagar
a_ocupados = 0
total_a_pagar = 0

print("\n***** BIENVENIDO AL SISTEMA DE VENTA DE ENTRADAS DE CINE ROYTS *****")
print("\nTe pediré algunos datos para personalizar la atención:")

# Solicitar al usuario los datos de la compra
nombre = input("Por favor, indícame tu nombre: ")
edad = int(input("Ahora tu edad: "))

while True:
    print("\nTipos de Entrada")
    print("1. Normal: $8,000. ")
    print("2. VIP: $15,000. ")
    print("3. Estreno: $20,000.")
    tipo_entrada = input(f"{nombre}, elige la entrada que deseas comprar (Normal, VIP, Estreno): ")
    es_estudiante = input("¿Eres estudiante? (s/n): ") == 's'

    # Calcular el precio de la entrada
    if tipo_entrada.lower() == "NORMAL" or tipo_entrada == "1":
        precio = normal
    elif tipo_entrada.lower() == "VIP" or tipo_entrada == "2":
        precio = vip
    elif tipo_entrada.lower() == "ESTRENO" or tipo_entrada == "3":
        precio = estreno
    else:
        print("Tipo de entrada inválido. Por favor, inténtelo de nuevo.")
        continue

    # Aplicar descuento si es estudiante
    if es_estudiante:
        descuento = precio * descuento_est
        precio -= descuento

    # Reservar el siguiente asiento disponible
    for a in asientos:
        if a != "X":
            asiento = a
            index = asientos.index(a)
            asientos[index] = "X"
            a_ocupados += 1
            total_a_pagar += precio
            break
    else:
        print("Lo siento, no hay más asientos disponibles.")
        continue

    # Imprimir el ticket
    print("\t******************************")
    print("\t********* CINE ROYTS *********")
    print(f"\tEntrada N°: {a_ocupados}")
    print(f"\tNombre: {nombre}")
    print(f"\tEdad: {edad}")
    if tipo_entrada == "1":
        tipo_entrada_str = "Normal"
    elif tipo_entrada == "2":
        tipo_entrada_str = "VIP"
    elif tipo_entrada == "3":
        tipo_entrada_str = "Estreno"
    else:
        tipo_entrada_str = tipo_entrada
    print(f"\tTipo de Entrada: {tipo_entrada_str}")
    print(f"\tDescuento estudiante: ${'{:,}'.format(int(descuento))}" 
            if es_estudiante 
            else "\tDescuento estudiante: No")

    print(f"\tTotal a pagar: ${'{:,}'.format(int(total_a_pagar))}")
    print("\t******************************")

    # Mostrar los asientos comprados y disponibles
    print(f"Se han comprado {a_ocupados} asiento(s) de {len(asientos)} en total.")
    for i in range(0, 40, 10):
        print(f"[{asientos[i]}\t][{asientos[i+1]}\t][{asientos[i+2]}\t][{asientos[i+3]}\t][{asientos[i+4]}\t][{asientos[i+5]}\t][{asientos[i+6]}\t][{asientos[i+7]}\t][{asientos[i+8]}\t][{asientos[i+9]}\t]")

    # Preguntar si el usuario desea continuar comprando
    continuar = input(f"{nombre}, ¿Deseas comprar otra entrada? (s/n): ")
    if continuar.lower() != 's':
        print ("")
        print ("\t******************************************************************")
        print ("\t   GRACIAS POR UTILIZAR NUESTRO SISTEMA, DISFRUTA DE TU PELICULA ")
        print ("\t******************************************************************")
        break
