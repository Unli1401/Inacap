##################### EJERCICIO 4
#Creamos una lista vacía para almacenar a los empleados
empleados = []
usuario = input("Dame tu nombre por favor ")


while True:
    print("\nMenú:")
    print("1. Agregar empleado")
    print("2. Ver lista de empleados")
    print("3. Eliminar empleado")
    print("4. Salir")
    print ("")
    opcion = input("Muy bien {} selecciona una opción: ".format(usuario))
    print ("")
    
    if opcion == "1":
        print ("")
        nombre = input("OK {} por favor, ingresa el nombre del nuevo empleado: ".format(usuario))
        empleados.append(nombre)
        print("Listo {}, el empleado {} ha sido agregado.".format(usuario, nombre))
        print("************************")
        print("Lista actualizada")
        print(empleados)
        
    elif opcion == "2":
        print("Esta es la lista de empleados {}: ".format(usuario))
        for empleado in empleados:
            print(empleado)
    elif opcion == "3":
        print ("")
        print(empleados)
        print ("")
        nombre = input("Perfecto {}, ingresa el nombre del empleado a eliminar: ".format(usuario))
#        if nombre in empleados:
#            empleados.remove(nombre)
    ### ESTE SEGMENTO DE CODIGO, TRANSFORMA EL CONTENIDO DE LA LISTA EN MINUSCULAS,         
        nombre_minusculas = nombre.lower()
        if nombre_minusculas in map(str.lower, empleados):
          empleados = [empleado for empleado in empleados if empleado.lower() != nombre_minusculas]

          print("Hecho, {} ha sido eliminado de la lista de empleados.".format(nombre))
          print("************************")
          print("Lista actualizada")
          print(empleados)
        else:
            print("Lo siento {}, {} no se encuentra en la lista de empleados.".format(usuario, nombre))
    elif opcion == "4":
        print ("")
        print("Adiós {}.".format(usuario))
        break
    else:
        print("La opción que ingresaste no es válida, {}.\nPor favor, selecciona una opción del menú mostrado.".format(usuario, usuario))
