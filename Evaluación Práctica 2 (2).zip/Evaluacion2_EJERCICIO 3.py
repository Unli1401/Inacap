###################### EJERCICIO 3
#Suma de los digitos de un numero entero
numero = int(input("Ingresa el numero que deseas sumar sus digitos "))#12345
numero2 = numero
suma = 0
while numero:
    suma += numero % 10
    numero //= 10

print("Ingresaste {}, la suma de estos dígitos es: {}" .format(numero2, suma)) #suma)