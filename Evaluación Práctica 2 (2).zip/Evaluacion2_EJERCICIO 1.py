################### EJERCICIO 1
# Calcular el área de un triángulo
# Está orientado a que un usuario ingrese cada uno de los datos.
continuar = "si"

while continuar.lower() == "si" or continuar.lower () == "s":
    base = int(input("Ingresa el valor de la base: "))
    altura = int(input("Ingresa el valor de la altura del triángulo: "))
    
    area = (base * altura) // 2
    
    print("El área del triángulo que tiene como base {} y altura {} es {}.".format(base, altura, area))
    
    continuar = input("¿Calculamos otro ? : ")