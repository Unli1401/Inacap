########################## EJERCICIO 2
# Sumar los primeros 10 números naturales
resultado = sum(range(1, 11))
print(resultado)


##ESTO ES SOLO LOCURA

inicio = int(input("Ingresa un valor inicial "))
final = int(input("Ingresa el numero final "))
resultado = sum(range(inicio, final))
resultado += 1
print (resultado)