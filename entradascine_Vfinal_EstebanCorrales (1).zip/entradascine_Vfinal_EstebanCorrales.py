normal = int(8000)
vip = int(15000)
estreno = int(20000)
desc_estudiante = float(0.8)
descuento = float(0.2)

total_normal = 0
total_normal_est = 0
total_vip = 0
total_vip_est = 0
total_estreno = 0
total_estreno_est = 0
valor_entrada = 0

print (" ******************************************************************************* ")
print (" ********** BIENVENIDO AL SISTEMA DE COMPRAS DE ENTRADAS DE CINE ROYTS  ********* ")
print (" ******************************************************************************* ")
nombre = input("Ingresa tu nombre: ")
edad = input("Ingresa tu edad: ")

while True:
    
    
    print(f"\nElije tu Entrada, {nombre}")
    print("1. Normal: $8.000. ")
    print("2. VIP: $15.000. ")
    print("3. Estreno: $20.000.")

    tipo_entrada = input("Ingresa el tipo de entrada -->: ")
    
    # Validar que la entrada sea válida
    if tipo_entrada not in ["1", "2", "3"]:
        print("\n>>>>>> Ingresa una opción válida (1, 2 o 3) <<<<<<")
        continue

    
    estudiante = input("Eres estudiante? (S/N): ")
    if estudiante not in ["s", "n"]:
        print (">>>>>> Ingresa 'S' para Sí o 'N' para No <<<<<<")
        continue
    

    # Entrada Normal
    if estudiante.lower() == "s" and tipo_entrada == "1":
        valor_entrada_est = normal * desc_estudiante
        valor_a_descontar = normal * descuento
        total_normal_est += 1
        tipo_entrada_str = "Normal"
        print(f"\n--> {nombre}, por ser estudiante se aplicará un descuento de ${'{:,}'.format(int(valor_a_descontar))}.")
        print(f"\nValor de la entrada: ${'{:,}'.format(int(valor_entrada_est))}")
        
    elif estudiante.lower() == "n" and tipo_entrada == "1":
        valor_entrada = normal
        total_normal += 1
        tipo_entrada_str = "Normal"
        print(f"\nValor de la entrada: ${'{:,}'.format(int(valor_entrada))}")
      
    # Entrada VIP
    elif estudiante.lower() == "s" and tipo_entrada == "2":
        valor_entrada_est = vip * desc_estudiante
        valor_a_descontar = vip * descuento
        total_vip_est += 1
        tipo_entrada_str = "VIP"
        print(f"\n--> {nombre}, por ser estudiante se aplicará un descuento de ${'{:,}'.format(int(valor_a_descontar))}.")
        print(f"\nValor de la entrada: ${'{:,}'.format(int(valor_entrada_est))}")
    elif estudiante.lower() != "s" and tipo_entrada == "2":
        valor_entrada = vip
        total_vip += 1
        tipo_entrada_str = "VIP"
        print(f"\nValor de la entrada: ${'{:,}'.format(int(valor_entrada))}")
    
    # Entrada Estreno
    elif estudiante.lower() == "s" and tipo_entrada == "3":
        valor_entrada_est = estreno * desc_estudiante
        valor_a_descontar = estreno * descuento
        total_estreno_est += 1
        tipo_entrada_str = "Estreno"
        print(f"\n--> {nombre}, por ser estudiante se aplicará un descuento de ${'{:,}'.format(int(valor_a_descontar))}.")
        print(f"\nValor de la entrada: ${'{:,}'.format(int(valor_entrada_est))}")
    elif estudiante.lower() != "s" and tipo_entrada == "3":
        valor_entrada = estreno
        total_estreno += 1
        tipo_entrada_str = "Estreno"
        print(f"\nValor de la entrada: ${'{:,}'.format(int(valor_entrada))}")
    
    seguir = input("Comprar otra entrada? S/N: ")
    if seguir.lower() == "s":
        continue
    else:
        break


total_ventas = (total_normal * normal) + (total_vip * vip) + (total_estreno * estreno) + (total_normal_est * (normal * desc_estudiante)) + (total_vip_est * (vip * desc_estudiante)) + (total_estreno_est * (estreno * desc_estudiante))
print ("**************************************")
print(f"****   Total de ventas: ${'{:,}'.format(int(total_ventas))}   ****")
print ("**************************************")

print("\nResumen de entradas vendidas:")
print(f"Entradas Normales: {total_normal}")
print(f"Entradas VIP: {total_vip}")
print(f"Entradas de Estreno: {total_estreno}")

print("\nEntradas con descuento Estudiante: ")
print(f"Entradas Normales Estudiante: {total_normal_est}")
print(f"Entradas VIP Estudiante: {total_vip_est}")
print(f"Entradas Estreno Estudiante: {total_estreno_est}")
print ()
print (" ********** GRACIAS POR COMPRAR CON NOSOTROS, ESPERAMOS QUE DISFRUTES TU PELICULA ********** ")


"""print("*************************************")
print("************CINE ROYTS***************")
print(f"*** Cantidad de entradas {total_normal + total_normal_est + total_vip + total_vip_est + total_estreno + total_estreno_est}")
print(f"*** Nombre: {nombre}")
print(f"*** Edad: {edad}")
print(f"*** Tipo de entrada: {tipo_entrada_str}")
if estudiante.lower() == "s":
    print(f"*** Descuento por estudiante: ${'{:,}'.format(int(valor_entrada_est - valor_entrada))}")
else:
    print(f"*** Descuento por estudiante: $0")
print(f"\n*** Total a pagar: ${'{:,}'.format(int(total_ventas))}")
"""